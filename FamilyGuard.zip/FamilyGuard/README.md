# Family Guard

Admin-controlled app blocker + per-user time limits + face / fingerprint / password login.
**Enforcement only runs while the charger is NOT connected** - plug in a charger and everything stops instantly.

## Build the APK
**Android Studio:** File > Open this folder > wait for Gradle sync > Build > Build APK(s).
**No PC? GitHub:** upload this folder to a new repo > Actions > "Build APK" > Run workflow > download artifact `FamilyGuard-apk`.
(Signed with the debug key so it installs directly. This project has not been compiled in the chat sandbox - if Gradle reports an error, send it to Claude and it will be fixed.)

## First-time setup
1. Install the APK, open **Family Guard**, create the **admin passcode** (the app asks for it every time it is opened).
2. Tap **Activate device admin** and **Enable accessibility service** (turn on "Family Guard"). Android will show a restricted-setting warning on newer versions: App info > top-right menu > "Allow restricted settings".
3. Choose 1 or 2 users, names, daily limit in minutes, user passwords; tick the apps to block; **SAVE**.
4. Optional hard mode (blocked apps are truly suspended and can't be uninstalled): remove all accounts from the phone, enable USB debugging, then
   `adb shell dpm set-device-owner com.family.guard/.AdminReceiver`

## If you get locked out (recovery)
1. **Plug in a charger** - all blocking and limits switch off immediately. Go to Settings and change anything you want.
2. On any lock screen press **Admin override (1 min)** and enter the admin passcode.
3. While the Family Guard admin panel is open, nothing is enforced; enforcement comes back 1 minute after you leave it (3 minutes after opening the device-admin / accessibility screens from the panel).
4. **Safe mode** (hold power-off > long-press > Safe mode): third-party accessibility services are disabled, so you can remove device admin and uninstall.
5. Device Owner mode only: uninstall is blocked by Android. For an easy exit add `android:testOnly="true"` to the `<application>` tag, install with `adb install -t`, and later run `adb shell dpm remove-active-admin com.family.guard/.AdminReceiver`. Without that, the last resort is a factory reset.
6. Forgot the admin passcode: use 1, 4 or 5.
The Phone dialer and emergency calls are never blocked.

## How it behaves (v1.3)
- **Only the apps you choose are controlled.** Everything else opens freely, with no login.
- Each chosen app is one of two kinds (set in Controlled apps > Choose apps):
  1. **Timer app**: opening it asks login (pick user if more than one > face > fingerprint > password, only the steps enabled for that user) and then it opens. Time is counted only while that app is on screen. When the app's daily minutes (or the user's optional total daily cap) are used up, the app is blocked for the rest of the day.
  2. **Block fully (no timer)**: shows "Blocked by Phone". "Click to know more" shows an information message about a hard block. That message is only text - no extra hard block exists behind it.
- Leaving the app (home, another app, screen off) keeps it unlocked for the "stay unlocked" seconds (default 30); after that, opening it asks login again. The login screen never shows up on its own.
- The timer badge in the corner can be switched off in Settings. Charging switches all control off.
- Without Device Owner, a blocked/timed-out app is covered by the lock screen the moment it opens; uninstall dialogs and Family Guard's own Settings pages are bounced back. Other uninstall routes (e.g. Play Store) are not intercepted.

## Known limits
- Face: enroll per user in the admin panel (Enroll face, then Test face to tune the threshold). It compares face-contour shape plus a blink check - fine for family use, not bank-grade.
- Fingerprint: Android stores fingerprints; apps cannot tell fingers apart. Any finger enrolled on the phone passes. If none is enrolled the step is skipped so you can't lock yourself out.
- Plugging in a charger disables protection by design - anyone can do it.
