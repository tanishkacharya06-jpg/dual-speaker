package com.family.guard

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
    companion object {
        @Volatile var showing = false      // lock screen is on top
        @Volatile var reason = ""
        @Volatile var pkg = ""             // the app this lock screen is about
        @Volatile var flowActive = false   // a login (face/fingerprint/password) is in progress
    }

    private var picked = 0

    private val faceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) fingerStep() else fail("Face not verified")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        flowActive = false
        show(intent.getStringExtra("reason") ?: "login", intent.getStringExtra("pkg") ?: "")
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        val np = i.getStringExtra("pkg") ?: ""
        if (np != pkg) flowActive = false      // a different app was opened: restart for that app
        show(i.getStringExtra("reason") ?: "login", np)
    }

    override fun onResume() { super.onResume(); showing = true }
    override fun onStop() { super.onStop(); showing = false }
    override fun onDestroy() { super.onDestroy(); showing = false; flowActive = false }

    // back always leaves: cancelling a lock must never reveal the app behind it
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun fail(m: String) { flowActive = false; Ui.toast(this, m) }

    private fun appLabel() = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { "this app" }

    private fun show(r: String, p: String) {
        pkg = p
        build(r)
        if (r == "login" && !flowActive) startLogin()   // starts straight away, no extra tap
    }

    private fun build(r: String) {
        reason = r
        val app = appLabel()
        val (icon, title, sub) = when (r) {
            "blocked" -> Triple("\uD83D\uDEAB", "Blocked by Phone", if (pkg.isEmpty()) "This is blocked." else "$app is blocked.")
            "timeup" -> Triple("\u23F3", "Time's up", "Your time for $app is over. It stays blocked for the rest of the day.")
            "admin" -> Triple("\uD83D\uDD12", "Admin only", "This page is protected by the admin.")
            else -> Triple("\uD83D\uDC4B", "Welcome", "Log in to open $app.")
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1E1B4B"), Color.parseColor("#4F46E5"))
            )
            val p = Ui.dp(this@LockActivity, 28); setPadding(p, p, p, p)
        }
        root.addView(TextView(this).apply { text = icon; textSize = 64f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = title; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = sub; textSize = 15f; setTextColor(Color.parseColor("#C7D2FE")); gravity = Gravity.CENTER
            setPadding(0, 8, 0, if (r == "blocked") 8 else 32)
        })
        if (r == "blocked") {
            // information only - there is no extra hard block behind this text
            root.addView(TextView(this).apply {
                text = "Click to know more"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
                setPadding(0, 8, 0, 32)
                setOnClickListener {
                    AlertDialog.Builder(this@LockActivity).setTitle("Hard block")
                        .setMessage("This is a hard block. When it is turned on it will comply with Android codes and can't be turned off easily.")
                        .setPositiveButton("OK", null).show()
                }
            })
        }
        val primary = if (r == "login") Ui.button(this, "Log in") { if (!flowActive) startLogin() }
        else Ui.button(this, "Go home") { goHome() }
        primary.background = Ui.bg(this, Color.WHITE, 16); primary.setTextColor(Ui.INDIGO)
        root.addView(primary)
        root.addView(Ui.button(this, "Phone / Emergency call", false) {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        root.addView(Ui.button(this, "Admin override (1 min)", false) {
            Ui.askAdmin(this, {
                Store.setOverrideUntil(this, System.currentTimeMillis() + 60_000)
                Enforcer.sync(this); finish()
            })
        })
        setContentView(root)
    }

    // ---- login: choose user -> face (if enrolled) -> fingerprint (if required) -> password (if set) ----
    private fun startLogin() {
        flowActive = true
        val ids = Store.userIds(this)
        if (ids.size == 1) { picked = ids[0]; faceStep(); return }
        val names = Array(ids.size) { Store.name(this, ids[it]) }
        AlertDialog.Builder(this).setTitle("Which user are you?")
            .setItems(names) { _, which -> picked = ids[which]; faceStep() }
            .setOnCancelListener { flowActive = false }.show()
    }

    private fun faceStep() {
        if (Store.reqFace(this, picked) && Store.faceVec(this, picked) != null)
            faceLauncher.launch(Intent(this, FaceActivity::class.java).putExtra("mode", "verify").putExtra("uid", picked))
        else fingerStep()
    }

    private fun fingerStep() {
        if (!Store.reqFinger(this, picked)) { passStep(); return }
        val ok = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (ok != BiometricManager.BIOMETRIC_SUCCESS) {
            Ui.toast(this, "No fingerprint enrolled on this phone - step skipped"); passStep(); return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { passStep() }
                override fun onAuthenticationError(code: Int, s: CharSequence) { fail("Fingerprint cancelled") }
            })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Fingerprint")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
    }

    private fun passStep() {
        if (!Store.userPassSet(this, picked)) { done(); return }
        Ui.passDialog(this, "Password for ${Store.name(this, picked)}", {
            if (Store.checkUserPass(this, picked, it)) done()
            else { Ui.toast(this, "Wrong password"); passStep() }
        }, { flowActive = false })
    }

    private fun done() {
        flowActive = false
        if (Store.exhausted(this, picked, pkg)) { build("timeup"); return }   // today's time is already used up
        Session.pkg = pkg; Session.user = picked; Session.leftAt = 0L
        finish()                                                               // back to the app, unlocked
    }
}
