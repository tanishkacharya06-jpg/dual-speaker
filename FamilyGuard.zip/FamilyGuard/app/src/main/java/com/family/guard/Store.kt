package com.family.guard

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.security.MessageDigest
import java.time.LocalDate

object Store {
    private fun p(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)
    fun hash(s: String): String = MessageDigest.getInstance("SHA-256")
        .digest("fg:$s".toByteArray()).joinToString("") { "%02x".format(it) }

    // ---- admin ----
    fun adminPassSet(c: Context) = p(c).contains("adminHash")
    fun setAdminPass(c: Context, s: String) = p(c).edit().putString("adminHash", hash(s)).apply()
    fun checkAdmin(c: Context, s: String) = p(c).getString("adminHash", null) == hash(s)

    // ---- users, each with a stable id ----
    fun userIds(c: Context): List<Int> =
        (p(c).getString("ids", "1") ?: "1").split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(1) }
    fun setUserIds(c: Context, l: List<Int>) = p(c).edit().putString("ids", l.joinToString(",")).apply()
    fun userCount(c: Context) = userIds(c).size
    fun nextId(ctx: Context): Int {
        val mx = userIds(ctx).maxOrNull() ?: 0
        val n = maxOf(p(ctx).getInt("nextId", 1), mx + 1)
        p(ctx).edit().putInt("nextId", n + 1).apply()
        return n
    }
    fun deleteUser(c: Context, id: Int) = p(c).edit()
        .remove("name$id").remove("limit$id").remove("upw$id").remove("face$id")
        .remove("reqFace$id").remove("reqFinger$id").remove("ut$id").apply()

    fun name(c: Context, id: Int) = p(c).getString("name$id", "User $id")!!
    fun setName(c: Context, id: Int, s: String) = p(c).edit().putString("name$id", s).apply()
    fun limitMin(c: Context, id: Int) = p(c).getInt("limit$id", 0)   // total minutes/day across timed apps, 0 = no cap
    fun setLimit(c: Context, id: Int, m: Int) = p(c).edit().putInt("limit$id", m).apply()

    // user passwords are stored readable on purpose, so the admin can view them
    fun userPassSet(c: Context, id: Int) = !p(c).getString("upw$id", "").isNullOrEmpty()
    fun userPass(c: Context, id: Int) = p(c).getString("upw$id", "")!!
    fun setUserPass(c: Context, id: Int, s: String) = p(c).edit().putString("upw$id", s).apply()
    fun checkUserPass(c: Context, id: Int, s: String) = userPassSet(c, id) && userPass(c, id) == s

    // per-user login steps
    fun faceVec(c: Context, id: Int): FloatArray? =
        p(c).getString("face$id", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }?.toFloatArray()?.takeIf { it.isNotEmpty() }
    fun setFaceVec(c: Context, id: Int, v: FloatArray) = p(c).edit().putString("face$id", v.joinToString(",")).apply()
    fun reqFace(c: Context, id: Int) = p(c).getBoolean("reqFace$id", false)
    fun setReqFace(c: Context, id: Int, b: Boolean) = p(c).edit().putBoolean("reqFace$id", b).apply()
    fun reqFinger(c: Context, id: Int) = p(c).getBoolean("reqFinger$id", false)
    fun setReqFinger(c: Context, id: Int, b: Boolean) = p(c).edit().putBoolean("reqFinger$id", b).apply()

    // ---- daily usage per user and per app (resets each day) ----
    private fun day() = LocalDate.now().toString()
    fun appUsedMs(c: Context, id: Int, pkg: String): Long {
        val k = "au$id:$pkg"
        return if (p(c).getString("$k.d", "") != day()) 0L else p(c).getLong(k, 0L)
    }
    fun userTotalMs(c: Context, id: Int): Long {
        val k = "ut$id"
        return if (p(c).getString("$k.d", "") != day()) 0L else p(c).getLong(k, 0L)
    }
    fun addAppUsed(c: Context, id: Int, pkg: String, ms: Long) {
        val k = "au$id:$pkg"; val t = "ut$id"
        p(c).edit()
            .putString("$k.d", day()).putLong(k, appUsedMs(c, id, pkg) + ms)
            .putString("$t.d", day()).putLong(t, userTotalMs(c, id) + ms).apply()
    }
    /** true when this user has used up the app's daily timer (or their total daily cap) */
    fun exhausted(c: Context, id: Int, pkg: String): Boolean {
        if (!limitsOn(c)) return false
        val am = appMin(c, pkg)
        if (am > 0 && appUsedMs(c, id, pkg) >= am * 60_000L) return true
        val cap = limitMin(c, id)
        return cap > 0 && userTotalMs(c, id) >= cap * 60_000L
    }

    // ---- blocked apps ----
    fun blocked(c: Context): Set<String> = p(c).getStringSet("blocked", emptySet())!!.toSet()
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", s).apply()
    /** per selected app: -1 = blocked (no timer), N > 0 = login to open + N minutes per day */
    fun appMin(c: Context, pkg: String) = p(c).getInt("amin$pkg", -1)
    fun setAppMin(c: Context, pkg: String, m: Int) = p(c).edit().putInt("amin$pkg", m).apply()
    fun applied(c: Context): Set<String> = p(c).getStringSet("applied", emptySet())!!.toSet()
    fun setApplied(c: Context, s: Set<String>) = p(c).edit().putStringSet("applied", s).apply()

    // ---- session + override ----
    fun session(c: Context) = p(c).getInt("session", 0)
    fun setSession(c: Context, i: Int) = p(c).edit().putInt("session", i).apply()
    fun lastOff(c: Context) = p(c).getLong("lastOff", 0L)
    fun setLastOff(c: Context, t: Long) = p(c).edit().putLong("lastOff", t).apply()
    fun overrideUntil(c: Context) = p(c).getLong("override", 0L)
    fun setOverrideUntil(c: Context, t: Long) = p(c).edit().putLong("override", t).apply()

    // ---- switches / numbers ----
    fun limitsOn(c: Context) = p(c).getBoolean("limitsOn", true)
    fun setLimitsOn(c: Context, b: Boolean) = p(c).edit().putBoolean("limitsOn", b).apply()
    fun showTimer(c: Context) = p(c).getBoolean("showTimer", true)
    fun setShowTimer(c: Context, b: Boolean) = p(c).edit().putBoolean("showTimer", b).apply()
    /** seconds an app stays unlocked after you leave it (or the screen turns off) */
    fun relogSec(c: Context) = p(c).getInt("relogSec", 30)
    fun setRelogSec(c: Context, m: Int) = p(c).edit().putInt("relogSec", m).apply()
    /** face match: average landmark distance (in eye-distance units); lower = stricter */
    fun faceThr(c: Context) = p(c).getFloat("faceThr", 0.10f)
    fun setFaceThr(c: Context, f: Float) = p(c).edit().putFloat("faceThr", f).apply()
}

object Charge {
    fun isCharging(c: Context): Boolean {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
    }
}

/** Who is unlocked right now: one app, one user. Cleared when the app is closed. */
object Session {
    @Volatile var pkg = ""
    @Volatile var user = 0
    @Volatile var leftAt = 0L
    fun clear() { pkg = ""; user = 0; leftAt = 0L }
}
