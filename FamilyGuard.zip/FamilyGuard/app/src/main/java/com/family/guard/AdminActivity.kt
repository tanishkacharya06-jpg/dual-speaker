package com.family.guard

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class AdminActivity : AppCompatActivity() {
    private class Row(
        val id: Int, val box: LinearLayout, val name: EditText, val limit: EditText, val pass: EditText,
        val reqFace: CheckBox, val reqFinger: CheckBox, val faceStatus: TextView
    )

    private var authed = false
    private var grace = 60_000L           // enforcement stays off this long after leaving the panel
    private var pausedAt = 0L
    private lateinit var col: LinearLayout
    private lateinit var usersBox: LinearLayout
    private lateinit var blockedSummary: TextView
    private lateinit var relogField: EditText
    private lateinit var thrField: EditText
    private val rows = mutableListOf<Row>()
    private val sel = mutableMapOf<String, Int>()   // pkg -> -1 (blocked, no timer) or minutes per day
    private var allApps: List<Pair<String, String>>? = null

    private val faceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refreshFaceStatus() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Store.adminPassSet(this)) setup()
        else Ui.askAdmin(this, { enter() }, { finish() })
    }

    private fun setup() = Ui.passDialog(this, "Create admin passcode (min 4 characters)", {
        if (it.length >= 4) { Store.setAdminPass(this, it); enter() }
        else { Ui.toast(this, "Too short"); setup() }
    }, { finish() })

    private fun enter() { authed = true; pauseEnforcement(); show() }

    private fun pauseEnforcement() {
        Store.setOverrideUntil(this, System.currentTimeMillis() + 60 * 60_000)
        Enforcer.sync(this)
    }

    override fun onResume() {
        super.onResume()
        if (!authed) return
        // coming back after the grace time: the panel must not stay open without the passcode
        if (pausedAt != 0L && SystemClock.elapsedRealtime() - pausedAt > grace + 5_000) { finish(); return }
        grace = 60_000L; pausedAt = 0L
        pauseEnforcement()
    }

    // enforcement comes back 1 minute after the admin leaves the panel
    override fun onPause() {
        super.onPause()
        if (authed) {
            pausedAt = SystemClock.elapsedRealtime()
            Store.setOverrideUntil(this, System.currentTimeMillis() + grace)
        }
    }

    private fun a11yOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(packageName) == true

    private fun show() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, AdminReceiver::class.java)

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(this@AdminActivity, 16); setPadding(p, p, p, p)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(col) })

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#4338CA"), Color.parseColor("#7C3AED"))
            ).apply { cornerRadius = Ui.dp(this@AdminActivity, 24).toFloat() }
            val p = Ui.dp(this@AdminActivity, 22); setPadding(p, p, p, p)
            layoutParams = Ui.lp(this@AdminActivity, 8)
        }
        header.addView(TextView(this).apply { text = "\uD83D\uDEE1\uFE0F Family Guard"; textSize = 26f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        header.addView(TextView(this).apply { text = "Admin panel"; textSize = 14f; setTextColor(Color.parseColor("#E0E7FF")) })
        col.addView(header)

        // ---- setup ----
        val c1 = Ui.card(this, col)
        c1.addView(Ui.title(this, "Setup"))
        val status = Ui.body(this, "", Ui.TEXT)
        fun refresh() {
            fun d(ok: Boolean, t: String) = (if (ok) "\u2705 " else "\u274C ") + t
            status.text = d(dpm.isAdminActive(admin), "Device admin") + "\n" +
                d(a11yOn(), "Accessibility service (required)") + "\n" +
                d(dpm.isDeviceOwnerApp(packageName), "Device owner (optional hard block)")
        }
        refresh(); c1.addView(status)
        c1.addView(Ui.button(this, "1. Activate device admin") {
            grace = 180_000L
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Stops Family Guard from being uninstalled."))
        })
        c1.addView(Ui.button(this, "2. Enable accessibility service") {
            grace = 180_000L; startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        c1.addView(Ui.button(this, "Refresh status", false) { refresh() })

        // ---- settings ----
        val c2 = Ui.card(this, col)
        c2.addView(Ui.title(this, "Settings"))
        fun sw(t: String, v: Boolean, f: (Boolean) -> Unit) = SwitchCompat(this).apply {
            text = t; isChecked = v; textSize = 15f; setTextColor(Ui.TEXT)
            layoutParams = Ui.lp(this@AdminActivity, 10)
            setOnCheckedChangeListener { _, on -> f(on) }
        }.also { c2.addView(it) }
        sw("Enforce daily time limits", Store.limitsOn(this)) { Store.setLimitsOn(this, it) }
        sw("Show timer on screen", Store.showTimer(this)) { Store.setShowTimer(this, it) }
        c2.addView(Ui.body(this, "Stay unlocked after leaving an app or turning the screen off (seconds):"))
        relogField = Ui.field(this, "Minutes", Store.relogSec(this).toString(), InputType.TYPE_CLASS_NUMBER); c2.addView(relogField)
        c2.addView(Ui.body(this, "Face match threshold (lower = stricter, default 0.10). Use 'Test face' on a user to tune it:"))
        thrField = Ui.field(this, "Threshold", Store.faceThr(this).toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL); c2.addView(thrField)
        c2.addView(Ui.button(this, "Change admin passcode", false) {
            Ui.passDialog(this, "New admin passcode", { if (it.length >= 4) { Store.setAdminPass(this, it); Ui.toast(this, "Changed") } else Ui.toast(this, "Too short") })
        })

        // ---- fingerprint ----
        val cf = Ui.card(this, col)
        cf.addView(Ui.title(this, "Fingerprint"))
        cf.addView(Ui.body(this, "Fingerprints are stored by Android, not by this app. Add them in the phone's own settings (a screen lock is needed first). Any fingerprint enrolled on the phone will pass the fingerprint step. Then tick 'Require fingerprint' on each user below."))
        cf.addView(Ui.button(this, "Add / manage fingerprints") {
            grace = 180_000L
            try {
                startActivity(
                    if (Build.VERSION.SDK_INT >= 30) Intent(Settings.ACTION_BIOMETRIC_ENROLL).putExtra(
                        Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    else Intent(Settings.ACTION_SECURITY_SETTINGS)
                )
            } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        })
        cf.addView(Ui.button(this, "Test fingerprint", false) { testFinger() })

        // ---- users ----
        val c3 = Ui.card(this, col)
        c3.addView(Ui.title(this, "Users"))
        c3.addView(Ui.body(this, "Add as many users as you like. Each has an optional total daily cap, a password and optional face / fingerprint checks. Login order: face, fingerprint, password (only the steps you enable)."))
        usersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c3.addView(usersBox)
        rows.clear()
        for (id in Store.userIds(this)) addRow(id)
        c3.addView(Ui.button(this, "+ Add user", false) { addRow(Store.nextId(this)) })

        // ---- blocked apps ----
        sel.clear(); Store.blocked(this).forEach { sel[it] = Store.appMin(this, it) }
        val c4 = Ui.card(this, col)
        c4.addView(Ui.title(this, "Controlled apps"))
        c4.addView(Ui.body(this, "Only the apps you choose are controlled; all other apps open freely. Each chosen app either asks login and has a daily timer, or is fully blocked (no timer). When a timer runs out the app stays blocked for the rest of the day."))
        blockedSummary = Ui.body(this, ""); c4.addView(blockedSummary)
        updateSummary()
        c4.addView(Ui.button(this, "Choose apps") { pickApps() })

        col.addView(Ui.button(this, "SAVE ALL") { save() }.apply { layoutParams = Ui.lp(this@AdminActivity, 18) })
    }

    private fun addRow(id: Int) {
        val ctx = this
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.bg(ctx, Ui.BG, 16)
            val p = Ui.dp(ctx, 12); setPadding(p, p, p, p)
            layoutParams = Ui.lp(ctx, 10)
        }
        val n = Ui.field(ctx, "Name", Store.name(ctx, id))
        val l = Ui.field(ctx, "Total daily minutes on timed apps (0 = no cap)", Store.limitMin(ctx, id).toString(), InputType.TYPE_CLASS_NUMBER)
        val p = Ui.field(ctx, "Password (visible to admin)", Store.userPass(ctx, id))
        listOf(n, l, p).forEach { it.background = Ui.bg(ctx, Color.WHITE, 12); box.addView(it) }
        val faceStatus = Ui.body(ctx, "")
        val rf = CheckBox(ctx).apply { text = "Require face"; isChecked = Store.reqFace(ctx, id) }
        val rg = CheckBox(ctx).apply { text = "Require fingerprint"; isChecked = Store.reqFinger(ctx, id) }
        box.addView(faceStatus); box.addView(rf); box.addView(rg)
        box.addView(Ui.button(ctx, "Enroll face", false) { save(silent = true); faceLauncher.launch(Intent(ctx, FaceActivity::class.java).putExtra("mode", "enroll").putExtra("uid", id)) })
        box.addView(Ui.button(ctx, "Test face", false) {
            if (Store.faceVec(ctx, id) == null) Ui.toast(ctx, "Enroll a face first")
            else { save(silent = true); faceLauncher.launch(Intent(ctx, FaceActivity::class.java).putExtra("mode", "test").putExtra("uid", id)) }
        })
        val row = Row(id, box, n, l, p, rf, rg, faceStatus)
        box.addView(Ui.button(ctx, "Remove this user", false) {
            if (rows.size <= 1) Ui.toast(ctx, "At least one user is required")
            else { rows.remove(row); usersBox.removeView(box) }
        }.apply { setTextColor(Ui.RED) })
        rows.add(row); usersBox.addView(box)
        refreshFaceStatus()
    }

    private fun refreshFaceStatus() {
        rows.forEach {
            val has = Store.faceVec(this, it.id) != null
            it.faceStatus.text = if (has) "\u2705 Face enrolled" else "\u274C No face enrolled"
            it.reqFace.isChecked = if (has) Store.reqFace(this, it.id) || it.reqFace.isChecked else false
        }
    }

    private fun testFinger() {
        val ok = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (ok != BiometricManager.BIOMETRIC_SUCCESS) { Ui.toast(this, "No fingerprint enrolled yet - add one first"); return }
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { Ui.toast(this@AdminActivity, "Fingerprint OK") }
        }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Test fingerprint").setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
    }

    private fun updateSummary() {
        blockedSummary.text = if (sel.isEmpty()) "No apps selected yet."
        else "${sel.size} app(s):\n" + sel.entries.sortedBy { labelOf(it.key).lowercase() }
            .joinToString("\n") { "\u2022 ${labelOf(it.key)} - " + (if (it.value <= 0) "blocked" else "${it.value} min/day") }
    }

    private fun labelOf(pkg: String) = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun pickApps() {
        if (allApps == null) {
            allApps = packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            ).map { it.activityInfo.packageName }.distinct().filter { it != packageName }
                .map { it to labelOf(it) }.sortedBy { it.second.lowercase() }
        }
        val ctx = this
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(ctx, 16); setPadding(p, p, p, 0)
        }
        val q = Ui.field(ctx, "Search apps...", "").apply { imeOptions = EditorInfo.IME_ACTION_SEARCH; isSingleLine = true }
        val selOnly = CheckBox(ctx).apply { text = "Show selected only" }
        val count = Ui.body(ctx, "")
        val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(ctx).apply {
            addView(listBox)
            layoutParams = LinearLayout.LayoutParams(-1, Ui.dp(ctx, 320)).apply { topMargin = Ui.dp(ctx, 8) }
        }
        fun render() {
            listBox.removeAllViews()
            val t = q.text.toString().trim().lowercase()
            val items = allApps!!.filter { (t.isEmpty() || it.second.lowercase().contains(t)) && (!selOnly.isChecked || it.first in sel) }
            fun refreshCount() { count.text = "${sel.size} selected - ${items.size} shown" }
            items.forEach { (pkg, lab) ->
                val cur = sel[pkg]
                val cb = CheckBox(ctx).apply { text = lab; isChecked = cur != null; textSize = 15f }
                val cfg = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val mins = Ui.field(ctx, "min/day", (if (cur != null && cur > 0) cur else 30).toString(), InputType.TYPE_CLASS_NUMBER)
                    .apply { layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 90), -2) }
                val noTimer = CheckBox(ctx).apply { text = "Block fully (no timer)"; isChecked = cur != null && cur <= 0 }
                cfg.addView(mins); cfg.addView(noTimer)
                cfg.visibility = if (cur != null) android.view.View.VISIBLE else android.view.View.GONE
                fun apply() {
                    mins.isEnabled = !noTimer.isChecked
                    cfg.visibility = if (cb.isChecked) android.view.View.VISIBLE else android.view.View.GONE
                    if (!cb.isChecked) sel.remove(pkg)
                    else sel[pkg] = if (noTimer.isChecked) -1 else (mins.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 30)
                    refreshCount()
                }
                cb.setOnCheckedChangeListener { _, _ -> apply() }
                noTimer.setOnCheckedChangeListener { _, _ -> apply() }
                mins.addTextChangedListener(object : android.text.TextWatcher {
                    override fun afterTextChanged(e: android.text.Editable?) { if (cb.isChecked && !noTimer.isChecked) apply() }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
                mins.isEnabled = !noTimer.isChecked
                listBox.addView(cb); listBox.addView(cfg)
            }
            refreshCount()
        }
        val applyBtn = Ui.button(ctx, "Apply filter") { render() }
        q.setOnEditorActionListener { _, _, _ -> render(); true }
        box.addView(q); box.addView(selOnly); box.addView(applyBtn); box.addView(count); box.addView(sv)
        render()
        AlertDialog.Builder(ctx).setTitle("Choose apps").setView(box)
            .setPositiveButton("Done") { _, _ -> updateSummary() }.show()
    }

    private fun save(silent: Boolean = false) {
        val old = Store.userIds(this)
        val ids = rows.map { it.id }
        (old - ids.toSet()).forEach { Store.deleteUser(this, it) }
        Store.setUserIds(this, ids)
        rows.forEachIndexed { idx, r ->
            Store.setName(this, r.id, r.name.text.toString().ifBlank { "User ${idx + 1}" })
            Store.setLimit(this, r.id, r.limit.text.toString().toIntOrNull() ?: 0)
            Store.setUserPass(this, r.id, r.pass.text.toString())
            val hasFace = Store.faceVec(this, r.id) != null
            Store.setReqFace(this, r.id, r.reqFace.isChecked && hasFace)
            Store.setReqFinger(this, r.id, r.reqFinger.isChecked)
            if (r.reqFace.isChecked && !hasFace && !silent) Ui.toast(this, "${r.name.text}: enroll a face first")
        }
        Store.setRelogSec(this, relogField.text.toString().toIntOrNull() ?: 30)
        Store.setFaceThr(this, thrField.text.toString().toFloatOrNull() ?: 0.10f)
        if (Session.user !in ids) Session.clear()
        Store.setBlocked(this, sel.keys.toSet())
        sel.forEach { (pkg, m) -> Store.setAppMin(this, pkg, m) }
        Enforcer.sync(this)
        if (!silent) Ui.toast(this, "Saved")
    }
}
