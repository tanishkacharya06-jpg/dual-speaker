package com.family.guard

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object Ui {
    val INDIGO = Color.parseColor("#4F46E5")
    val INDIGO_SOFT = Color.parseColor("#EEF2FF")
    val BG = Color.parseColor("#F3F4F6")
    val TEXT = Color.parseColor("#111827")
    val MUTED = Color.parseColor("#6B7280")
    val RED = Color.parseColor("#DC2626")
    val GREEN = Color.parseColor("#16A34A")

    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density).toInt()
    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

    fun bg(c: Context, color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(c, radiusDp).toFloat()
    }

    fun lp(c: Context, top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(c, top) }

    fun card(c: Context, parent: LinearLayout): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(c, Color.WHITE, 20)
        val p = dp(c, 16); setPadding(p, p, p, p)
        layoutParams = lp(c, 14)
        elevation = dp(c, 2).toFloat()
        parent.addView(this)
    }

    fun title(c: Context, t: String) = TextView(c).apply {
        text = t; textSize = 17f; setTextColor(TEXT); typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    fun body(c: Context, t: String, color: Int = MUTED) = TextView(c).apply {
        text = t; textSize = 13.5f; setTextColor(color); layoutParams = lp(c, 4)
    }

    fun button(c: Context, text: String, filled: Boolean = true, onClick: () -> Unit) = Button(c).apply {
        this.text = text; isAllCaps = false; textSize = 15f
        setTextColor(if (filled) Color.WHITE else INDIGO)
        background = bg(c, if (filled) INDIGO else INDIGO_SOFT, 14)
        stateListAnimator = null; minHeight = dp(c, 48)
        layoutParams = lp(c, 10)
        setOnClickListener { onClick() }
    }

    fun field(c: Context, hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(c).apply {
        this.hint = hint; setText(value); inputType = type; textSize = 15f
        setTextColor(TEXT); setHintTextColor(MUTED)
        background = bg(c, BG, 12)
        val p = dp(c, 12); setPadding(p, p, p, p)
        layoutParams = lp(c, 8)
    }

    fun passDialog(a: Activity, title: String, onOk: (String) -> Unit, onCancel: () -> Unit = {}) {
        val e = EditText(a)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        AlertDialog.Builder(a).setTitle(title).setView(e).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> onOk(e.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> onCancel() }.show()
    }

    fun askAdmin(a: Activity, onOk: () -> Unit, onCancel: () -> Unit = {}) {
        passDialog(a, "Admin passcode", {
            if (Store.checkAdmin(a, it)) onOk() else { toast(a, "Wrong passcode"); onCancel() }
        }, onCancel)
    }
}
