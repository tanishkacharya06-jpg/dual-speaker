package com.family.guard

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PointF
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Basic face matcher built on ML Kit face contours (no external model needed).
 * It compares the shape of the face (oval, eyebrows, nose, eyes) normalised by eye distance.
 * It is good enough to tell family members apart in most cases but it is NOT bank-grade:
 * swap in a TFLite embedding model (e.g. MobileFaceNet) here for stronger matching.
 */
object FaceMatcher {
    private val types = intArrayOf(
        FaceContour.FACE, FaceContour.LEFT_EYEBROW_TOP, FaceContour.LEFT_EYEBROW_BOTTOM,
        FaceContour.RIGHT_EYEBROW_TOP, FaceContour.RIGHT_EYEBROW_BOTTOM,
        FaceContour.NOSE_BRIDGE, FaceContour.NOSE_BOTTOM, FaceContour.LEFT_EYE, FaceContour.RIGHT_EYE
    )

    fun vector(f: Face): FloatArray? {
        val pts = ArrayList<PointF>()
        for (t in types) { val c = f.getContour(t) ?: return null; pts.addAll(c.points) }
        val le = f.getContour(FaceContour.LEFT_EYE)?.points ?: return null
        val re = f.getContour(FaceContour.RIGHT_EYE)?.points ?: return null
        if (le.isEmpty() || re.isEmpty()) return null
        val lx = le.map { it.x }.average(); val ly = le.map { it.y }.average()
        val rx = re.map { it.x }.average(); val ry = re.map { it.y }.average()
        val cx = (lx + rx) / 2; val cy = (ly + ry) / 2
        val dx = rx - lx; val dy = ry - ly
        val d = hypot(dx, dy)
        if (d < 1.0) return null
        val cos = dx / d; val sin = dy / d
        val out = FloatArray(pts.size * 2)
        pts.forEachIndexed { i, p ->
            val x = (p.x - cx) / d; val y = (p.y - cy) / d
            out[2 * i] = (x * cos + y * sin).toFloat()
            out[2 * i + 1] = (-x * sin + y * cos).toFloat()
        }
        return out
    }

    fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 99f
        var s = 0.0
        for (i in 0 until a.size / 2) s += hypot((a[2 * i] - b[2 * i]).toDouble(), (a[2 * i + 1] - b[2 * i + 1]).toDouble())
        return (s / (a.size / 2)).toFloat()
    }

    fun average(list: List<FloatArray>): FloatArray {
        val out = FloatArray(list[0].size)
        for (v in list) for (i in out.indices) out[i] += v[i] / list.size
        return out
    }
}

/** extras: mode = "enroll" | "verify" | "test", uid = user id */
class FaceActivity : AppCompatActivity() {
    private var mode = "verify"
    private var uid = 0
    private var state = 0
    private var lastSample = 0L
    private val samples = ArrayList<FloatArray>()
    private var enrolled: FloatArray? = null
    private var thr = 0.10f
    private lateinit var pv: PreviewView
    private lateinit var msg: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        mode = intent.getStringExtra("mode") ?: "verify"
        uid = intent.getIntExtra("uid", 0)
        thr = Store.faceThr(this)
        enrolled = Store.faceVec(this, uid)
        if (mode != "enroll" && enrolled == null) { Ui.toast(this, "No face enrolled for this user"); setResult(RESULT_CANCELED); finish(); return }

        pv = PreviewView(this)
        msg = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt())
            gravity = Gravity.CENTER; setPadding(32, 32, 32, 32)
            text = if (mode == "enroll") "Look straight at the camera" else "Look at the camera"
        }
        val root = FrameLayout(this)
        root.addView(pv)
        root.addView(msg, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) start()
        else { Ui.toast(this, "Camera permission is needed"); setResult(RESULT_CANCELED); finish() }
    }

    private fun start() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val provider = fut.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val det = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                    .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()
            )
            val an = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            an.setAnalyzer(ContextCompat.getMainExecutor(this)) { proxy ->
                val img = proxy.image
                if (img == null) { proxy.close(); return@setAnalyzer }
                det.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                    .addOnSuccessListener { handle(it) }
                    .addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handle(faces: List<Face>) {
        if (state >= 3) return
        if (faces.size != 1) { msg.text = "Show one face to the camera"; return }
        if (mode == "enroll") enrollFrame(faces[0]) else verifyFrame(faces[0])
    }

    private fun enrollFrame(f: Face) {
        if (abs(f.headEulerAngleY) > 12 || abs(f.headEulerAngleX) > 12) { msg.text = "Look straight at the camera"; return }
        val open = minOf(f.leftEyeOpenProbability ?: 0f, f.rightEyeOpenProbability ?: 0f) > 0.6f
        if (!open) { msg.text = "Keep your eyes open"; return }
        val now = SystemClock.elapsedRealtime()
        if (now - lastSample < 400) return
        val v = FaceMatcher.vector(f) ?: return
        lastSample = now
        samples.add(v)
        msg.text = "Hold still... ${samples.size}/8"
        if (samples.size >= 8) {
            state = 3
            Store.setFaceVec(this, uid, FaceMatcher.average(samples))
            Store.setReqFace(this, uid, true)
            Ui.toast(this, "Face saved")
            setResult(RESULT_OK); finish()
        }
    }

    private fun verifyFrame(f: Face) {
        val l = f.leftEyeOpenProbability ?: return
        val r = f.rightEyeOpenProbability ?: return
        val open = minOf(l, r) > 0.7f
        val closed = maxOf(l, r) < 0.3f
        val v = FaceMatcher.vector(f)
        val dist = if (v != null) FaceMatcher.distance(v, enrolled!!) else null
        val ok = dist != null && dist < thr
        if (mode == "test" && dist != null) msg.text = "distance %.3f (limit %.2f) - %s".format(dist, thr, if (ok) "MATCH" else "no match")
        when (state) {
            0 -> if (open && dist != null) {
                if (ok) { state = 1; if (mode != "test") msg.text = "Face recognised - now blink" }
                else if (mode != "test") msg.text = "Face not recognised"
            }
            1 -> if (closed) state = 2
            2 -> if (open && ok) { state = 3; setResult(RESULT_OK); finish() }
        }
    }
}
