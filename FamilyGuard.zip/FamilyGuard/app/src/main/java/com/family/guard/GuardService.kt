package com.family.guard

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.TextView

class GuardService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private var lastLock = 0L
    private var fg = ""
    private var overlay: TextView? = null

    private val tick = object : Runnable {
        override fun run() { onTick(); h.postDelayed(this, 3000) }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> if (Session.pkg.isNotEmpty() && Session.leftAt == 0L) Session.leftAt = System.currentTimeMillis()
                Intent.ACTION_SCREEN_ON -> screenOn()
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> Enforcer.sync(c)
            }
        }
    }

    override fun onServiceConnected() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(rx, f)
        Enforcer.sync(this)
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        setOverlay(null)
        try { unregisterReceiver(rx) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ---------- on-screen timer ----------
    private fun setOverlay(text: String?) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (text == null) {
            overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            overlay = null; return
        }
        if (overlay == null) {
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 13f
                val ph = Ui.dp(this@GuardService, 12); val pv = Ui.dp(this@GuardService, 6)
                setPadding(ph, pv, ph, pv)
                background = Ui.bg(this@GuardService, Color.parseColor("#CC1E1B4B"), 16)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; y = Ui.dp(this@GuardService, 48); x = Ui.dp(this@GuardService, 8) }
            try { wm.addView(tv, lp); overlay = tv } catch (_: Exception) { return }
        }
        overlay?.text = text
    }

    // ---------- lock screen ----------
    private fun lock(reason: String, pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (reason == "login" && LockActivity.flowActive && LockActivity.pkg == pkg) return
        if (LockActivity.showing && LockActivity.reason == reason && LockActivity.pkg == pkg) return
        if (now - lastLock < 800) return
        lastLock = now
        startActivity(Intent(this, LockActivity::class.java).putExtra("reason", reason).putExtra("pkg", pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun isIme(pkg: String) = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        .enabledInputMethodList.any { it.packageName == pkg }

    private fun label(pkg: String) = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun screenHas(text: String) =
        rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.isNotEmpty() == true

    // ---------- the core rule: only selected apps are controlled ----------
    private fun handleSelected(pkg: String) {
        if (Store.appMin(this, pkg) <= 0) { lock("blocked", pkg); return }          // no timer = blocked
        val u = Session.user
        val grace = Store.relogSec(this) * 1000L
        val valid = Session.pkg == pkg && u in Store.userIds(this) &&
            (Session.leftAt == 0L || System.currentTimeMillis() - Session.leftAt <= grace)
        if (valid) {
            Session.leftAt = 0L
            if (Store.exhausted(this, u, pkg)) lock("timeup", pkg)
            return
        }
        Session.clear()
        lock("login", pkg)                                                           // login to open
    }

    private fun screenOn() {
        if (Session.pkg.isEmpty()) return
        val grace = Store.relogSec(this) * 1000L
        if (Session.leftAt != 0L && System.currentTimeMillis() - Session.leftAt <= grace) { Session.leftAt = 0L; return }
        Session.clear()
        if (Enforcer.enforcing(this) && fg in Store.blocked(this)) handleSelected(fg)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        val isSettings = pkg.contains("settings")
        val isInstaller = pkg.contains("packageinstaller")
        val stateChange = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        if (!stateChange && !isSettings && !isInstaller) return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return
        if (stateChange && isIme(pkg)) return

        if (stateChange) {
            fg = pkg
            // leaving the unlocked app starts the "closed" countdown
            if (Session.pkg.isNotEmpty() && pkg != Session.pkg && Session.leftAt == 0L) Session.leftAt = System.currentTimeMillis()
        }
        if (!Enforcer.enforcing(this)) return

        val selected = Store.blocked(this)
        if (stateChange && pkg in selected) { handleSelected(pkg); return }

        if (isSettings && screenHas("Family Guard")) { lock("admin", ""); return }   // protects admin/accessibility/app-info pages
        if (isInstaller) {                                                           // protects uninstall dialogs
            val names = selected.map { label(it) } + "Family Guard"
            if (names.any { screenHas(it) }) { performGlobalAction(GLOBAL_ACTION_BACK); lock("blocked", "") }
        }
    }

    private fun onTick() {
        Enforcer.sync(this)
        // the app was closed long enough ago: forget the login
        if (Session.pkg.isNotEmpty() && Session.leftAt != 0L &&
            System.currentTimeMillis() - Session.leftAt > Store.relogSec(this) * 1000L) Session.clear()

        val interactive = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        val p = Session.pkg; val u = Session.user
        if (!Enforcer.enforcing(this) || !interactive || p.isEmpty() || fg != p ||
            u !in Store.userIds(this) || p !in Store.blocked(this) || Store.appMin(this, p) <= 0) {
            lastTick = 0; setOverlay(null); return
        }

        val now = SystemClock.elapsedRealtime()
        if (lastTick != 0L && Store.limitsOn(this)) Store.addAppUsed(this, u, p, now - lastTick)
        lastTick = now

        if (Store.limitsOn(this)) {
            val appLeft = Store.appMin(this, p) * 60_000L - Store.appUsedMs(this, u, p)
            val cap = Store.limitMin(this, u)
            val left = (if (cap > 0) minOf(appLeft, cap * 60_000L - Store.userTotalMs(this, u)) else appLeft).coerceAtLeast(0)
            if (Store.showTimer(this)) setOverlay("\u23F1 ${left / 60_000} min left") else setOverlay(null)
            if (left <= 0) lock("timeup", p)
        } else setOverlay(null)
    }
}
