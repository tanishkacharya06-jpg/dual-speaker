package com.example.speakersync

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class Entry(val name: String, val addr: String, val dev: AudioDeviceInfo?)

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var box: LinearLayout
    private lateinit var echoSw: Switch
    private var entries = listOf<Entry>()
    private val roleSp = HashMap<Int, Spinner>()
    private val delaySb = HashMap<Int, SeekBar>()
    private val roles = arrayOf("Main (full stereo)", "Left", "Right", "Subwoofer")
    private val routable get() = entries.indices.filter { entries[it].dev != null }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        status = TextView(this).apply { text = "Connect your Bluetooth speakers, then tap Scan."; textSize = 16f }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        echoSw = Switch(this).apply { text = "Echo mode"; setPadding(0, 24, 0, 24) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        root.addView(status)
        root.addView(btn("SCAN SPEAKERS") { scan() })
        root.addView(box)
        root.addView(btn("TEST ALL AT ONCE (different beep per speaker)") { testAll() })
        root.addView(echoSw)
        root.addView(btn("PICK SONG & PLAY ON ALL SPEAKERS") { pick() })
        root.addView(btn("MIRROR OTHER APPS TO SPEAKER 2") { mirror() })
        root.addView(btn("STOP") { stopService(Intent(this, AudioService::class.java)); status.text = "Stopped." })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun ensurePerms(): Boolean {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        val m = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (m.isNotEmpty()) { requestPermissions(m.toTypedArray(), 1); return false }
        return true
    }

    private fun audioBt(): List<AudioDeviceInfo> =
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            (Build.VERSION.SDK_INT >= 31 && (it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER))
        }

    private fun scan() {
        if (!ensurePerms()) { status.text = "Allow permissions, then tap Scan again."; return }
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { status.text = "Turn Bluetooth on first."; return }
        status.text = "Scanning..."
        ad.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(p: Int, proxy: BluetoothProfile) {
                val conns = proxy.connectedDevices.map { (it.name ?: "Speaker") to it.address }
                ad.closeProfileProxy(BluetoothProfile.A2DP, proxy)
                runOnUiThread { build(conns) }
            }
            override fun onServiceDisconnected(p: Int) {}
        }, BluetoothProfile.A2DP)
    }

    private fun build(conns: List<Pair<String, String>>) {
        val audio = audioBt()
        val list = conns.map { (n, a) -> Entry(n, a, audio.firstOrNull { it.address.equals(a, true) }) }.toMutableList()
        audio.filter { d -> list.none { it.dev?.id == d.id } }.forEach { list += Entry(d0(it), it.address, it) }
        entries = list.take(4)
        box.removeAllViews(); roleSp.clear(); delaySb.clear()
        entries.forEachIndexed { i, e ->
            box.addView(TextView(this).apply {
                text = "Speaker ${i + 1}: ${e.name}\n" + if (e.dev != null) "✔ can receive audio" else "✖ connected, but phone is NOT routing audio to it"
                textSize = 16f; setPadding(0, 28, 0, 0)
            })
            if (e.dev == null) return@forEachIndexed
            val sp = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, roles)
                setSelection(if (routable.size == 2) routable.indexOf(i) + 1 else 0)
            }
            val lab = TextView(this).apply { text = "Delay: 0 ms" }
            val sb = SeekBar(this).apply {
                max = 500
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { lab.text = "Delay: $p ms" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            val t = Button(this).apply { text = "TEST BEEP"; setOnClickListener { beep(listOf(e.dev)); status.text = "Beeping on ${e.name}..." } }
            box.addView(sp); box.addView(lab); box.addView(sb); box.addView(t)
            roleSp[i] = sp; delaySb[i] = sb
        }
        val n = entries.size; val m = routable.size
        status.text = when {
            n == 0 -> "No connected Bluetooth speakers found. Connect them and scan again."
            n >= 2 && m < 2 -> "$n speakers connected but only $m can receive audio. Your phone only routes audio to ONE Bluetooth speaker at a time (phone limitation). Try Settings > Bluetooth > Advanced > Dual audio, then Scan again."
            m < 2 -> "Only $n speaker found. Connect a second one."
            else -> "$m speakers can receive audio. Tap TEST ALL AT ONCE to confirm."
        }
    }

    private fun d0(d: AudioDeviceInfo) = d.productName.toString()

    private fun testAll() {
        val r = routable
        if (r.size < 2) { status.text = "Need 2 routable speakers. Scan first."; return }
        beep(r.map { entries[it].dev!! })
        status.text = "You should hear a low beep and a high beep at the same time. Heard both? Then your phone supports it. Heard only one? Phone limitation."
    }

    private fun beep(devs: List<AudioDeviceInfo>) {
        devs.forEachIndexed { i, d ->
            Thread {
                try {
                    val rate = 44100; val f = if (i == 0) 440.0 else 660.0
                    val s = ShortArray(rate * 2) { k -> (Math.sin(2 * Math.PI * f * (k / 2) / rate) * 12000).toInt().toShort() }
                    val t = AudioTrack.Builder()
                        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
                        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                        .setBufferSizeInBytes(s.size * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
                    t.preferredDevice = d
                    t.play(); t.write(s, 0, s.size); Thread.sleep(1200); t.stop(); t.release()
                } catch (e: Exception) { e.printStackTrace() }
            }.start()
        }
    }

    private fun putCfg(i: Intent, idx: List<Int>): Intent = i
        .putExtra("ids", idx.map { entries[it].dev!!.id }.toIntArray())
        .putExtra("roles", idx.map { roleSp[it]!!.selectedItemPosition }.toIntArray())
        .putExtra("delays", idx.map { delaySb[it]!!.progress }.toIntArray())
        .putExtra("echo", echoSw.isChecked)

    private fun pick() {
        if (routable.size < 2) { status.text = "Need 2 routable speakers. Scan first."; return }
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 3)
    }

    private fun mirror() {
        if (routable.size < 2) { status.text = "Need 2 routable speakers. Scan first."; return }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (res != RESULT_OK || d == null) { status.text = "Cancelled."; return }
        if (rc == 3) {
            val uri = d.data!!
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            startForegroundService(putCfg(Intent(this, AudioService::class.java), routable)
                .setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            status.text = "Playing on ${routable.size} speakers."
        } else if (rc == 2) {
            startForegroundService(putCfg(Intent(this, AudioService::class.java), listOf(routable[1]))
                .putExtra("mirror", true).putExtra("code", res).putExtra("proj", d))
            status.text = "Mirroring to speaker 2. Play anything now."
        }
    }
}
