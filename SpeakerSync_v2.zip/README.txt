BUILD THE APK (no Android Studio needed)
1. Create a free GitHub account, make a new repository, upload ALL files in this folder (keep the .github folder).
2. Open the repo > Actions tab > "Build APK" > wait ~5 minutes (or click Run workflow).
3. Open the finished run > Artifacts > download "SpeakerSync-apk" > unzip > app-debug.apk
4. Copy to your Samsung phone, allow "install unknown apps", install.

OR with Android Studio: open this folder > Build > Build APK(s).
